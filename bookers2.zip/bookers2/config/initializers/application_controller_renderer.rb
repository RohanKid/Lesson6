# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '5fc2abb2584c74923585b0a7614db7cba0bf265c70dd1cf10c2b9b2ddb9067e95edbbeb27f3a6864301308b0bda23598068c4d7e32cefb6e7dc467adedb746a0'